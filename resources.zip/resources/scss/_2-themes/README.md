# Canvas och teman

Kunden väljer en canvas i sidbyggaren. Valet ger sektionen en bakgrund, ett ljust eller mörkt läge och eventuella temaavvikelser.

| Del i `_1-lib/_tokens.scss` | Ansvar |
| --- | --- |
| `$colors` | Färgpaletten, exempelvis `blue-900`. |
| `$canvas-colors` | Kundens bakgrundsval, exempelvis `canvas-3`. Nyansen kan ändras utan att det sparade valet byter namn. |
| `$theme-colors` | Gemensamma färger, skrivna direkt som `light-dark()`-par. |
| `$themes` | Varje temas `color-scheme` och enbart dess färgavvikelser. |
| `$theme-by-background` | Vilket tema varje canvas använder. |

`_colors.scss` skriver ut variabler och klasser från mapparna. Sidbyggaren skriver exempelvis ut:

```html
<section class="bg-canvas-3">
  <!-- Blå bakgrund och dark-temats text och komponenter. -->
  <div class="bg-canvas-1">
    <!-- Egen rosa bakgrund och ett komplett light-tema. -->
  </div>
</section>
```

Basfärgerna skrivs ut en gång på root som exempelvis `--text-1: light-dark(var(--neutral-900), var(--neutral-50))`. Sektionens `color-scheme` väljer vilken färg som används. Komponenterna fortsätter använda `--text-1`, `--primary-bg` och övriga semantiska tokens.

Varianter anger bara sina ändringar. Vid varje ny canvas- eller `data-theme`-gräns återställs de variabler som förekommer som avvikelser i `$themes`. Därför får light inuti midnight tillbaka ljusa ytor, och dark inuti midnight får vanliga mörka ytor.

Selektorer som använder samma tema grupperas. Temamapparna behöver varken slås ihop eller jämföras.

## Ändra eller lägga till

- **Ändra bakgrundsfärg:** ändra värdet i `$canvas-colors`.
- **Byta tema för en canvas:** ändra `$theme-by-background`.
- **Lägga till en canvas:** lägg till den i båda mapparna och i `color_picker_options()` i `inc/Customization/Style_Options.php`. CSS-klassen genereras automatiskt.
- **Lägga till ett tema:** lägg till en post i `$themes` med `color-scheme` och de färger som ska avvika. Färgnycklarna ska finnas i `$theme-colors` så att de kan återställas vid nästa sektionsgräns.

Välj bakgrundsnyanser som ger kontrast mot temats text och felmeddelanden. Standardvalen använder ljusa bakgrunder för light och mörka för dark/midnight.

`data-theme="dark"` finns också för att enbart byta tema. Canvas-klassen behövs för att välja och måla en sektionsbakgrund.

## Kontroll

```sh
node console/check-theme-scss.mjs
```

Kontrollen verifierar färgpar på root, variantåterställning, canvas-kopplingar och att refererade palettfärger finns. Kontrollera även nästling och kontrast i webbläsaren när färger ändras.
